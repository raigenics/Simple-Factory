﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleFactory.ProductInterface
{
    public interface IMobile
    {
        void GetMobile();
    }
}
