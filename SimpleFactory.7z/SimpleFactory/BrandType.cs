﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SimpleFactory
{
    public enum BrandType
    {
        Samsung = 1,
        Xiaomi = 2
    }
}
